﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace filmsite.Models
{
    public class SendMovieRental
    {
        public string MovieId { get; set; }
    }
}