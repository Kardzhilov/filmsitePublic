The solution is implemented inside of task 1 and 2. 
You can navigate to the FAQ page by going to the bottom of the homescreen of the UserSite Homescreen (the one with all the movie posters)
At the bottom there is a "FAQ" hyperlink.

For the purposes of testing this task there is no need to run the Administration site, only the User site is needed.

------------------------------------------------

Admin login
Brukernavn: admin
Passord: 1234

Loggs blir lagret i database og i en fil som heter "FilmLogs.txt" som blir generert i Documents mappa til den som kjorer.

------------------------------------------------

**Gjelder FilmSiteUserApplication (forrige innlevering)**

Kode som vi fant p� nettet eller Canvas:
I Utilities:
	ListUtilities.cs

		Security.cs



I site-scrips.js
:	Delay function		Stack Overflow
: https://stackoverflow.com/questions/1909441/how-to-delay-the-keyup-handler-until-the-user-stops-typing

I MyMoviesConreoller.cs: DownloadFile()		Stack Overflow: https://stackoverflow.com/questions/5826649/returning-a-file-to-view-download-in-asp-net-mvc


Kul kode � legge merke til:
I Global.asax har vi lagt til egene ruter som lar oss redirigere fra en controller til action i andre controllere.


Andre merknader:
LogInModal er ikke en modal. Det var i f�lge planen ment � v�re en modal, men en missforst�else gjorde at vi lagde den som et eget view.
Vi hadde ikke tid til � rette opp dette, men kommer heller til � implementere det i senere versjoner.